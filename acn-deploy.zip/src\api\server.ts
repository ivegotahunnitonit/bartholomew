import http from 'node:http';
import { Ingestor } from '../engine/Ingestor.ts';
import { Matchmaker } from '../engine/Matchmaker.ts';
import { EscrowSettlement } from '../settlement/EscrowSettlement.ts';
import { config } from '../config.ts';
import { P2PManager } from '../network/P2PManager.ts';
import { db } from '../database/db.ts';

const PORT = process.env.API_PORT ? parseInt(process.env.API_PORT, 10) : 8090;

interface ApiKeyRecord {
  tier: 'free' | 'premium';
  requestCount: number;
}

const VALID_API_KEYS: Record<string, ApiKeyRecord> = {
  'acn_demo_free_key': { tier: 'free', requestCount: 0 },
  'acn_live_premium_key': { tier: 'premium', requestCount: 0 },
};

const IP_RATE_LIMITS: Map<string, { count: number; resetTime: number }> = new Map();
const RATE_LIMIT_MAX_REQUESTS = 60; // Max requests per minute
const RATE_LIMIT_WINDOW_MS = 60 * 1000;

function checkRateLimit(req: http.IncomingMessage): boolean {
  const ip = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
  const now = Date.now();
  const record = IP_RATE_LIMITS.get(ip);

  if (!record || now > record.resetTime) {
    IP_RATE_LIMITS.set(ip, { count: 1, resetTime: now + RATE_LIMIT_WINDOW_MS });
    return true;
  }

  if (record.count >= RATE_LIMIT_MAX_REQUESTS) {
    return false;
  }

  record.count++;
  return true;
}

function sendJSON(res: http.ServerResponse, statusCode: number, data: any) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-API-Key',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  });
  res.end(JSON.stringify(data));
}


function validateApiKey(req: http.IncomingMessage): { valid: boolean; tier?: string; error?: string } {
  const apiKey = req.headers['x-api-key'] as string;
  if (!apiKey) {
    // Unauthenticated public requests default to free tier (rate limited)
    return { valid: true, tier: 'free' };
  }

  const record = VALID_API_KEYS[apiKey];
  if (!record) {
    return { valid: false, error: 'Invalid API Key' };
  }

  record.requestCount++;
  return { valid: true, tier: record.tier };
}


export function startApiServer(): http.Server {
  const server = http.createServer(async (req, res) => {
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-API-Key',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      });
      return res.end();
    }

    if (!checkRateLimit(req)) {
      return sendJSON(res, 429, { success: false, error: 'Too many requests. Rate limit exceeded (60 req/min).' });
    }


    const url = new URL(req.url || '/', `http://${req.headers.host}`);

    // GET /.well-known/ai-plugin.json (AI Agent Tool Discovery)
    if (req.method === 'GET' && url.pathname === '/.well-known/ai-plugin.json') {
      return sendJSON(res, 200, {
        schema_version: 'v1',
        name_for_human: 'Autonomous Circularity Network (ACN)',
        name_for_model: 'acn_circular_trade',
        description_for_human: 'Autonomous circular economy matching and EVM escrow settlement network.',
        description_for_model: 'Plugin for querying industrial feedstock waste/need listings, triggering autonomous matchmaking, and initializing EVM escrow settlements.',
        auth: { type: 'user_http', authorization_type: 'bearer' },
        api: { type: 'openapi', url: `http://${req.headers.host}/api/v1/openapi.json` },
        logo_url: `http://${req.headers.host}/logo.png`,
        contact_email: 'support@acn.network',
        legal_info_url: `http://${req.headers.host}/legal`,
      });
    }

    // GET /api/v1/health
    if (req.method === 'GET' && url.pathname === '/api/v1/health') {

      return sendJSON(res, 200, {
        status: 'healthy',
        nodeId: config.NODE_ID || 'supernode-local',
        supernodeMode: config.SUPER_NODE_MODE,
        peersConnected: P2PManager.getConnectedPeerCount ? P2PManager.getConnectedPeerCount() : 0,
        timestamp: new Date().toISOString(),
      });
    }

    // GET /api/v1/listings
    if (req.method === 'GET' && url.pathname === '/api/v1/listings') {
      try {
        const stmt = db.prepare("SELECT * FROM listings WHERE status = 'active'");
        const listings = stmt.all();
        return sendJSON(res, 200, { success: true, count: listings.length, listings });
      } catch (err: any) {
        return sendJSON(res, 500, { success: false, error: err.message });
      }
    }

    // GET /api/v1/stream (Real-Time Server-Sent Events Stream)
    if (req.method === 'GET' && url.pathname === '/api/v1/stream') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*',
      });
      res.write(`data: ${JSON.stringify({ type: 'connected', message: 'ACN Real-Time Instant Stream Active', timestamp: new Date().toISOString() })}\n\n`);

      const keepAliveInterval = setInterval(() => {
        res.write(`data: ${JSON.stringify({ type: 'ping', timestamp: new Date().toISOString() })}\n\n`);
      }, 15000);

      req.on('close', () => {
        clearInterval(keepAliveInterval);
      });
      return;
    }

    // POST /api/v1/listings
    if (req.method === 'POST' && url.pathname === '/api/v1/listings') {
      let body = '';
      req.on('data', chunk => (body += chunk));
      req.on('end', async () => {
        try {
          const payload = JSON.parse(body);
          if (!payload.type || !payload.resource || !payload.quantity) {
            return sendJSON(res, 400, {
              success: false,
              error: 'Missing required fields: type, resource, quantity',
            });
          }

          const listingId = Ingestor.addListing({
            type: payload.type,
            resource: payload.resource,
            quantity: payload.quantity,
            unit: payload.unit || 'kg',
            price: payload.price || 0,
            lat: payload.lat || config.LAT || 39.7392,
            lng: payload.lng || config.LNG || -104.9903,
          });

          // Instant Event-Driven Matchmaking (0ms Latency Trigger)
          const instantMatches = Matchmaker.runMatching();

          return sendJSON(res, 201, { success: true, listingId, instantMatchesCreated: instantMatches.length });
        } catch (err: any) {
          return sendJSON(res, 400, { success: false, error: err.message });
        }
      });
      return;
    }


    // POST /api/v1/match
    if (req.method === 'POST' && url.pathname === '/api/v1/match') {
      try {
        const matches = Matchmaker.runMatching();
        return sendJSON(res, 200, { success: true, matchesCreated: matches.length, matches });
      } catch (err: any) {
        return sendJSON(res, 500, { success: false, error: err.message });
      }
    }

    // POST /api/v1/escrow/init
    if (req.method === 'POST' && url.pathname === '/api/v1/escrow/init') {
      let body = '';
      req.on('data', chunk => (body += chunk));
      req.on('end', async () => {
        try {
          const payload = JSON.parse(body);
          if (!payload.dealId || !payload.amountUsd || !payload.buyerAddress) {
            return sendJSON(res, 400, {
              success: false,
              error: 'Missing required fields: dealId, amountUsd, buyerAddress',
            });
          }

          const contract = await EscrowSettlement.initiateEscrow(
            payload.dealId,
            payload.amountUsd,
            payload.buyerAddress
          );

          return sendJSON(res, 200, { success: true, contract });
        } catch (err: any) {
          return sendJSON(res, 500, { success: false, error: err.message });
        }
      });
      return;
    }

    // 404 Route Not Found
    return sendJSON(res, 404, { success: false, error: 'Endpoint not found' });
  });

  server.listen(PORT, () => {
    console.log(`[ACN REST API] Enterprise API server listening on http://0.0.0.0:${PORT}`);
  });

  return server;
}

if (process.argv[1] && process.argv[1].endsWith('server.ts')) {
  startApiServer();
}
