# Autonomous Circularity Network (ACN)

> **ACN** is a peer-to-peer decentralised marketplace for industrial and post-consumer materials — connecting producers of waste streams with manufacturers who need those feedstocks, without any central broker. Each node runs a full matching engine, a lightweight wallet, and a gossip protocol, so the network self-organises and survives the loss of any individual participant.

---

## ✨ Quick Start

```bat
start.bat
```

Double-click **`start.bat`** (or run it from a terminal). It will:
1. Launch the ACN Node via Antigravity's `agy-node` runtime.
2. Open the dashboard at **http://localhost:8080** automatically after 3 seconds.
3. Keep the console window open so you can see live log output.

To stop the node, press `Ctrl+C` in the console window or run **`stop.bat`**.

---

## ⚙️ Configuration (`.env`)

Copy `.env.example` to `.env` and edit the values before starting.  
`start.bat` and `install.ps1` will do this automatically if `.env` doesn't yet exist.

| Variable | Default | Description |
|---|---|---|
| `PORT` | `8080` | HTTP port for the REST API and dashboard |
| `LAT` | `40.7128` | Node latitude (decimal degrees) |
| `LNG` | `-74.0060` | Node longitude (decimal degrees) |
| `BOOTSTRAP_PEERS` | _(empty)_ | Comma-separated list of peer URLs to join on startup |
| `FEE_RATE` | `0.01` | Transaction fee fraction (0.01 = 1 %) |
| `NODE_NAME` | `ACN-Node-Local` | Display name shown to peer nodes |
| `DATA_DIR` | `./data` | Directory for the SQLite DB and wallet |
| `LOG_LEVEL` | `info` | Verbosity: `error` \| `warn` \| `info` \| `debug` |

> **Tip:** Geolocation is used for proximity-weighted matching. Set `LAT`/`LNG` to your facility's coordinates for best results.

---

## 🌐 Connecting to the Network

1. Get the public URL of an existing ACN peer (e.g. `http://peer.example.com:8080`).
2. Either add it to `BOOTSTRAP_PEERS` in `.env` **before** starting, **or** open the dashboard → **Peers** tab → **Add Peer** and paste the URL live.
3. The node will exchange its known peer list (gossip) and begin syncing listings and matches automatically.

Your node's own address is shown in the dashboard header. Share it with others so they can connect to you.

---

## 🔁 Auto-Start on Windows Login

Run the installer **once** in an elevated PowerShell prompt:

```powershell
# Right-click PowerShell → "Run as Administrator"
.\install.ps1
```

This registers a Windows Task Scheduler task called **`ACN-Node`** that launches the node automatically every time you log in. The task also starts the node immediately so you don't need to reboot.

To remove auto-start:

```powershell
.\uninstall.ps1
```

---

## 🔌 REST API Endpoints

All endpoints are served at `http://localhost:<PORT>`.

### Status & Data

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/status` | Node health, uptime, version, wallet balance |
| `GET` | `/api/listings` | All active materials listings on this node |
| `GET` | `/api/matches` | Current pending and confirmed material matches |
| `GET` | `/api/transactions` | Completed transactions with fee breakdowns |
| `GET` | `/api/peers` | Connected peer nodes and their metadata |
| `GET` | `/api/wallet` | Wallet address, balance, and transaction history |

### Writing Data

| Method | Endpoint | Body | Description |
|---|---|---|---|
| `POST` | `/api/listings` | `{ material, quantity, unit, lat, lng }` | Publish a new materials listing |
| `DELETE` | `/api/listings/:id` | — | Remove a listing |

---

## 📡 P2P Endpoints

These are consumed by peer nodes during gossip. You generally don't call them directly.

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/p2p/register` | Register this node with a remote peer |
| `GET` | `/p2p/peers` | Return this node's known peer list |
| `POST` | `/p2p/gossip` | Accept gossip payload (listings, matches, transactions) |

---

## 🗂 Project Structure

```
autonomous-circularity-network/
├── src/
│   ├── index.ts          # Entry point — wires server, engine, network
│   ├── config.ts         # .env loader and validated config object
│   ├── engine/           # Matching engine and wallet logic
│   ├── network/          # P2P gossip and peer management
│   └── database/         # SQLite persistence layer
├── dashboard/            # Static HTML/CSS/JS dashboard UI
├── data/                 # Runtime data (DB, wallet) — git-ignored
├── .env.example          # Configuration template
├── .env                  # Your local config (create from example)
├── start.bat             # One-click launcher (Windows)
├── stop.bat              # Graceful shutdown (Windows)
├── install.ps1           # Register auto-start scheduled task
├── uninstall.ps1         # Remove auto-start scheduled task
├── package.json
└── tsconfig.json
```

---

## 🛠 Requirements

| Requirement | Notes |
|---|---|
| **Antigravity IDE** | Provides the `agy-node` runtime (Node.js v24 with TypeScript strip-types support) |
| **Windows 10/11** | Required for the `.bat` launchers and Task Scheduler integration |
| **No npm/Node install needed** | `agy-node` is fully self-contained inside Antigravity IDE |

---

## 📜 License

MIT — see `LICENSE` for details.
