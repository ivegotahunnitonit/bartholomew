import { loadConfig, config } from './config.ts';
import { initDatabase } from './database/db.ts';
import { Ingestor } from './engine/Ingestor.ts';
import { Matchmaker } from './engine/Matchmaker.ts';
import { startExternalMatchScout } from './engine/ExternalMatchScout.ts';
import { startServer } from './network/Server.ts';
import { P2PManager } from './network/P2PManager.ts';
import { startSettlementEngine } from './settlement/PaymentManager.ts';
import { AdRevenueAgent } from './agents/AdRevenueAgent.ts';
import { CpuMinerAgent } from './agents/CpuMinerAgent.ts';
import { StratumProxyServer } from './agents/StratumProxyServer.ts';
import { NodeOrchestrator } from './network/NodeOrchestrator.ts';
import { ArbitrageEngine } from './settlement/ArbitrageEngine.ts';

async function main() {
  console.log('==================================================');
  console.log('   BARTHOLOMEW — Autonomous Circularity Network   ');
  console.log('==================================================');

  // 1. Load configuration and generate Node identity
  loadConfig();

  // 2. Initialize SQLite Database Sync
  initDatabase();

  // 3. Seed node capabilities and high-volume commercial listings
  Ingestor.seedCapabilities(config.LAT, config.LNG);
  Ingestor.seedCommercialListings(config.LAT, config.LNG);
  // 4. Run initial matchmaking cycle
  Matchmaker.runMatching();


  // 5. Initialize P2P Network Bootstrap connections
  try {
    await P2PManager.bootstrap();
  } catch (p2pErr: any) {
    console.warn('[P2P] Bootstrapping failed:', p2pErr.message);
  }

  // 6. Start HTTP Server & Operator Dashboard API
  startServer();

  // Start cooperating sub-node cluster if Supernode mode is enabled
  if (config.SUPER_NODE_MODE) {
    // NodeOrchestrator.startCluster(4); // Disabled to prevent VM memory exhaustion
  }

  // 7. Start Payment Settlement Engine (auto-confirms pending txs after 5 seconds)
  startSettlementEngine();
  // CpuMinerAgent.start(); // Disabled by operator (unprofitable)
  // const stratumPort = 7914 + (config.PORT - 8080);
  // StratumProxyServer.start(stratumPort); // Disabled by operator (unprofitable)
  // AdRevenueAgent.start(); // Archived by operator request
  // ArbitrageEngine.start(); // Archived by operator request (no mock yields)

  // 8. Ultra-Fast High-Frequency Trading (HFT) Loop (Sub-1ms Microtask Reaction Speed)
  function runUltraFastHftLoop() {
    try {
      Matchmaker.runMatching();
    } catch (err) {
      console.error('[Ultra-Fast HFT] Error in event loop tick:', err);
    }
    // Execute on immediate process tick (<1ms V8 event loop latency)
    setImmediate(runUltraFastHftLoop);
  }
  runUltraFastHftLoop();



  // 9. Schedule continuous P2P peer checks and discovery (every 60 seconds)
  setInterval(() => {
    P2PManager.pingPeers().catch(err => {
      console.error('[Background P2P] Peer checks error:', err);
    });
  }, 60000);

  // 10. Start External Match Scout (polls peers + public feeds every 45s)
  startExternalMatchScout(45_000);

  console.log('[Bartholomew] Node is active and running autonomously.');

  // 11. Graceful exit process hooks to terminate all cluster sub-nodes
  process.on('SIGINT', () => {
    console.log('\n[System] SIGINT received. Shutting down orchestrator cluster...');
    NodeOrchestrator.terminateAll();
    process.exit(0);
  });

  process.on('SIGTERM', () => {
    console.log('\n[System] SIGTERM received. Shutting down orchestrator cluster...');
    NodeOrchestrator.terminateAll();
    process.exit(0);
  });
}

main().catch(err => {
  console.error('[Fatal System Error]:', err);
});
